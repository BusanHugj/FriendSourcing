package com.javalec.friendsourcing.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.friendsourcing.dao.daoTG;
import com.javalec.friendsourcing.dto.FeedDto;
import com.javalec.friendsourcing.dto.FollowDto;

@Service
public class ServiceImplTG implements serviceTG{
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public void fileUpload(String uploadpath, String uuid, String filename,String memId) {
		daoTG dao = sqlSession.getMapper(daoTG.class);
		dao.fileUpload(uploadpath,uuid,filename,memId);
	}
	
	@Override
	public void FeedUpload(HashMap<String, String> param) {
		daoTG dao = sqlSession.getMapper(daoTG.class);
		System.out.println("feedimg param var : "+param.get("var"));
		System.out.println("feedimg param filename : "+param.get("filename"));
		System.out.println("feedimg param uuid : "+param.get("uuid"));
		System.out.println("feedimg param uploadpath : "+param.get("uploadpath"));
		dao.feedUpload(param);
	}
	
	@Override
	public String feedNum() {
		daoTG dao = sqlSession.getMapper(daoTG.class);
		return dao.feedNum();
	}
	@Override
	public String feedCount() {
		daoTG dao = sqlSession.getMapper(daoTG.class);
		return dao.feedCount();
	}
	
	//��ü �ǵ�
	@Override
	public ArrayList<FeedDto> feedList(int startRowNum,int endRowNum) {
		daoTG dao = sqlSession.getMapper(daoTG.class);
		ArrayList<FeedDto> list = dao.feedList(startRowNum,endRowNum);
		
		return list;
	}
	
	  // ���ǵ� or �ȷο��ǵ�
	  
	 @Override 
	 public ArrayList<FeedDto> followfeedList(HashMap<String, Object> param) { 
		  daoTG dao = sqlSession.getMapper(daoTG.class); 
		  ArrayList<FeedDto> list = dao.followfeedList(param);
	  
	 return list; 
	 }
	 
	 @Override
		public ArrayList<FeedDto> myLikeFeedList(HashMap<String, Object> param) {
		
			daoTG dao1 = sqlSession.getMapper(daoTG.class);
			 ArrayList<FeedDto> list = dao1.myLikeFeedList(param);
			  
			 return list;
		}

		@Override
		public ArrayList<FeedDto> myTagFeedList(HashMap<String, Object> param) {
			
			daoTG dao1 = sqlSession.getMapper(daoTG.class);
			ArrayList<FeedDto> list = dao1.myTagFeedList(param);
			
			return list;
		}

		@Override
		public ArrayList<FeedDto> myFeedList(HashMap<String, Object> param) {
			
			daoTG dao1 = sqlSession.getMapper(daoTG.class);
			ArrayList<FeedDto> list = dao1.myFeedList(param);
			
			return list;
		}

	@Override
	public int feedFollow(HashMap<String, String> param) {
		daoTG dao = sqlSession.getMapper(daoTG.class);
		int s = dao.feedFollow(param);
		
		return s;
	}
	
	
	@Override
	public String[] followListView(HashMap<String, String> param) {
		daoTG dao = sqlSession.getMapper(daoTG.class);
		String[] list = dao.followListView(param);
		
		return list;
	}
	
	@Override
	public int followDelete(HashMap<String, String> param) {
		daoTG dao = sqlSession.getMapper(daoTG.class);
		
		return dao.followDelete(param);
	}


	@Override
	public void tagInsert(HashMap<String, String> param) {
		daoTG dao = sqlSession.getMapper(daoTG.class);
		dao.tagInsert(param);
	}
	
	@Override
	public void hashtagInsert(HashMap<String, String> param) {
		daoTG dao = sqlSession.getMapper(daoTG.class);
		dao.hashtagInsert(param);
	}
	

}
